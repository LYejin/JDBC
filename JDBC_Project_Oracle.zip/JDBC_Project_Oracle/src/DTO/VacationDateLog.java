package DTO;

import lombok.Data;

@Data
public class VacationDateLog {
	private int vacationId;
	private String attendanceId;
	private int vacationPeriod;
}
