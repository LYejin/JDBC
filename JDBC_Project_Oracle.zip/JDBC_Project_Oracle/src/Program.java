import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Program {
	public static void main(String[] args) throws Exception {
//		Dept dept = new Dept("AAA", "IT", "춘천", 1000);
//		DeptDao deptDao = new DeptDao();
//		deptDao.dataInsert(dept);
		
		//Emp emp = new Emp(1000, "이예진", "개발", 600, "AAA");
//		Emp emp = new Emp(2000, "김예진", "개발", 400, "AAA", 1000);
//		EmpDao empDao = new EmpDao();
//		empDao.dataInsert(emp);
		
		// 근태 분류
//		AttendanceCode attCode = new AttendanceCode("2000b", "휴가");
//		AttendanceCodeDao attCodeDao = new AttendanceCodeDao();
//		attCodeDao.dataInsert(attCode);
		
		//근태 기록 확인 
//		AttendanceLogDao attLogDao = new AttendanceLogDao();
//		attLogDao.getCommuteSatusLogSearch();
		
		ProgramMenu pm = new ProgramMenu();
		pm.totalMenu();
		
	}
}
 